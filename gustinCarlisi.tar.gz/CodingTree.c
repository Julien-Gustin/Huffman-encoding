#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

#include "CodingTree.h"
#include "PriorityQueue.h"
#include "BinarySequence.h"
static const size_t ASCII_SIZE = 127;


/* ------------------------------------------------------------------------- *
 * Trouve l'équivalant binaire pour chaque caractere, en traversant l'arbre dans
 * son entierté de tel maniere que si on passe par l'enfant gauche on met un 0,
 * et 1 si on passe à droite, et stocke la suite de bit dans le tableau
 *
 * PARAMETERS
 * tree     la structure, coding tree
 * bs       tableau de pointeur vers la structure BinarySequence
 *
 * ------------------------------------------------------------------------- */
static void reccBinary(const CodingTree *tree, BinarySequence **bs);

struct coding_tree_t{

  /* Si pas de d'enfant => feuille */
  CodingTree *left; // enfant gauche du noeud
  CodingTree *right; // enfant droite du noeud

  /* data */
  double frequence; // contient les fréquences du noeuds
  char caractere; // si caractere == -1 => noeud != feuile
  BinarySequence *binary;
};

CodingTree* ctCreateLeaf(char c, double frequency){
  CodingTree *feuille = malloc(sizeof(CodingTree));
  if(feuille == NULL)
    return NULL;

  feuille->frequence = frequency; // contient la fréquence du caractère associé
  feuille->caractere = c;
  feuille->binary = biseCreate();

  feuille->left = NULL; //init les enfants à NULL
  feuille->right = NULL;

  return feuille;
}

CodingTree* ctMerge(CodingTree* leftTree, CodingTree* rightTree){

  CodingTree *parent = ctCreateLeaf(-1, leftTree->frequence + rightTree->frequence);
  if(parent ==  NULL)
    return NULL;

  /* parent des deux arbres données en arguments */
  parent->left = leftTree;
  parent->right = rightTree;

  return parent;
}

CodingTree* ctHuffman(const double* frequencies){
  size_t tailleFrequencies = ASCII_SIZE;
  CodingTree **racines = malloc(sizeof(CodingTree*)*tailleFrequencies); // crée un tableau de racine contenant les caractere avec leurs fréquence
  if(racines == NULL){
    free(racines);
    return NULL;
  }

  for(size_t i = 0; i < tailleFrequencies; i++){
    racines[i] = ctCreateLeaf((char)(i), frequencies[i]); // crée une racine pour chaque caractère avec sa fréquence
    if(racines[i] == NULL){
      for(size_t j = 0; j <= i; j++)
        ctFree(racines[j]);

      return NULL;
    }
  }

  PriorityQueue *pq = pqCreate((void*)(racines), frequencies, tailleFrequencies); // priotity queue min
  if(pq == NULL){
    for(size_t i = 0; i < tailleFrequencies; i++)
      ctFree(racines[i]);

    pqFree(pq);
    return NULL; //free tab
  }

  for(size_t i = 0; i < tailleFrequencies-1; i++){ // Huffman algorithm
    CodingTree *leftTree = (CodingTree*)(pqExtractMin(pq));
    CodingTree *rightTree = (CodingTree*)(pqExtractMin(pq));

    CodingTree *z = ctMerge(leftTree, rightTree); // créer une racine avec comme enfants, les 2 elements minimum de la priority queue

    if(z == NULL){
      for(size_t j = 0; j < tailleFrequencies; j++)
        ctFree(racines[j]);

      ctFree(z);
      pqFree(pq);
      return NULL;
    }

    pqInsert(pq, z, z->frequence); //on insere la racine cree dans la queue

  }
  CodingTree *returned = (CodingTree*)(pqExtractMin(pq));

  free(racines);
  pqFree(pq);
  return returned; // on return le dernier element, soit l'arbre entier
}

void ctFree(CodingTree *tree){
  if(tree->left != NULL){
    CodingTree *tmpLeft = tree->left;
    ctFree(tmpLeft);
  }

  if(tree->right != NULL){
    CodingTree *tmpRight = tree->right;
    ctFree(tmpRight);
  }

  if(tree->caractere == -1) // pour l'encodage
    biseFree(tree->binary);

  free(tree);
  return;
}

BinarySequence** ctCodingTable(const CodingTree* tree){

  BinarySequence **bs = malloc(sizeof(BinarySequence*) *ASCII_SIZE);
  if(bs == NULL){
    free(bs);
    return NULL;
  }
  reccBinary(tree, bs); //remplit le tableau de pointeurs bs
  return bs;
}

static void reccBinary(const CodingTree *tree, BinarySequence **bs){

  if(tree->left != NULL){ // si à gauche on rajoute un 0 à la fin de la sequence
    biseAddSequence(tree->left->binary, tree->binary);
    biseAddBit(tree->left->binary, 0);
    reccBinary(tree->left, bs);
  }

  if(tree->right != NULL){ // si à droite on rajoute un 1 à la fin de la séquence
    biseAddSequence(tree->right->binary, tree->binary);
    biseAddBit(tree->right->binary, 1);
    reccBinary(tree->right, bs);
  }

  if(tree->right == NULL && tree->left == NULL){
    bs[(int)(tree->caractere)] = tree->binary;
    return;
  }
}

Decoded ctDecode(const CodingTree* tree, const BinarySequence* encodedSequence, size_t start){
  if(tree->left == NULL && tree->right == NULL){
    Decoded test;
    test.character = tree->caractere;
    test.nextBit = start;
    return test;
  }

  if(biseGetBit(encodedSequence, start) == 0)
    return(ctDecode(tree->left, encodedSequence, start+1));

  return(ctDecode(tree->right, encodedSequence, start+1));

}
